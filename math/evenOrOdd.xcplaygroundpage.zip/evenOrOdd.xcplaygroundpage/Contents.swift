//: [Previous](@previous)

import UIKit

func evenOrOdd(_ number : Int) -> String {
    return number % 2 != 0 ? "Odd" : "Even"
}

//Examples:

evenOrOdd(77)  //"Odd"
evenOrOdd(34)  //"Even"

//: [Next](@next)
